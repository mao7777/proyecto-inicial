import {User} from '../model/user';
export const USERS: User[] = [
    {
        id: 1,
        name: "Pedro Perez",
        age: 23,
        adress: "Kra 15"
       
    },
    {
        id: 2,
        name: "Juan Ambrosio",
        age: 34,
        adress: "Calle 13"
    },
    {
        id: 3,
        name: "Jacinto Navarrete",
        age: 25,
        adress: "Diag 23"
    }
];